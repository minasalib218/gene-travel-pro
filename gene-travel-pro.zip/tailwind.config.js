module.exports = {
  content: ["./app/**/*.{js,ts,jsx,tsx}","./components/**/*.{js,ts,jsx,tsx}"],
  theme: { extend: { colors: { brand: "#ff7a00" }, boxShadow: { glass: "0 18px 45px rgba(0,0,0,0.55)" } } },
  plugins: []
};
