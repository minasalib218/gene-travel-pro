export type PlanSummary={id:string;title:string;subtitle:string;days:number;budgetBand:string;image:string;tags:string[]};
export const plans:PlanSummary[]=[
 {id:"patagonia-adventure",title:"Patagonia Peaks Adventure",subtitle:"For hikers & mountain lovers",days:7,budgetBand:"$$",image:"/images/patagonia.jpg",tags:["Adventure","Nature","Hiking"]},
 {id:"dubai-luxury",title:"Dubai Luxury Escape",subtitle:"Skyline views & desert nights",days:5,budgetBand:"$$$",image:"/images/dubai.jpg",tags:["Luxury","Shopping","City"]},
 {id:"paris-romance",title:"Paris Romance & Art",subtitle:"Museums, streets & sunsets",days:4,budgetBand:"$$",image:"/images/paris.jpg",tags:["Romantic","Culture","Food"]},
];
