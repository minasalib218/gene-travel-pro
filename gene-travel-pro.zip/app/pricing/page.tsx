import Navbar from "@/components/Navbar";
const tiers=[
 {name:"Basic",price:25,description:"3 AI plans • edits open 3 days"},
 {name:"Pro",price:40,description:"5 AI plans • edits open 6 days"},
 {name:"Agency",price:50,description:"8 AI plans • edits open 2 weeks • expert revision"},
];
export default function PricingPage(){
  return(<main className="min-h-screen bg-black text-white">
    <Navbar/>
    <section className="pt-28 pb-16 max-w-5xl mx-auto px-4">
      <h1 className="text-3xl font-semibold mb-4">Pricing & Passes</h1>
      <p className="text-sm text-white/70 mb-10 max-w-2xl">After secure payment, you&apos;ll be sent to sign up and then the AI Planner.</p>
      <div className="grid gap-6 md:grid-cols-3">
        {tiers.map(t=>(
          <div key={t.name} className="rounded-3xl bg-white/5 border border-white/10 p-6 hover:bg-white/10 transition">
            <h2 className="text-xl font-semibold mb-2">{t.name}</h2>
            <p className="text-3xl font-bold mb-2">${t.price}</p>
            <p className="text-xs text-white/70 mb-4">{t.description}</p>
            <button className="w-full rounded-full bg-brand hover:opacity-90 text-black text-sm py-2 transition">Continue to secure payment</button>
          </div>
        ))}
      </div>
    </section>
  </main>);
}
