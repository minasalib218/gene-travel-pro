import Navbar from "@/components/Navbar";
export default function PlannerPage(){
  return(<main className="min-h-screen bg-black text-white">
    <Navbar/>
    <section className="pt-28 pb-16 max-w-3xl mx-auto px-4 space-y-6">
      <h1 className="text-3xl font-semibold">Create your smart plan</h1>
      <p className="text-sm text-white/70 max-w-xl">Describe your trip. Later this will send data to the Day Timeline Editor.</p>
      <form className="space-y-4 text-sm">
        <div><label className="block mb-1 text-white/80">Destination(s)</label><input className="w-full rounded-xl bg-white/5 border border-white/10 px-3 py-2 outline-none" placeholder="e.g., Dubai, Paris, Tokyo"/></div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div><label className="block mb-1 text-white/80">Start date</label><input type="date" className="w-full rounded-xl bg-white/5 border border-white/10 px-3 py-2 outline-none"/></div>
          <div><label className="block mb-1 text-white/80">End date</label><input type="date" className="w-full rounded-xl bg-white/5 border border-white/10 px-3 py-2 outline-none"/></div>
        </div>
        <div><label className="block mb-1 text-white/80">Budget</label><input className="w-full rounded-xl bg-white/5 border border-white/10 px-3 py-2 outline-none" placeholder="Total budget in USD"/></div>
        <div><label className="block mb-1 text-white/80">Travel style</label>
          <select className="w-full rounded-xl bg-white/5 border border-white/10 px-3 py-2 outline-none">
            <option>Chill</option><option>Balanced</option><option>Active</option><option>Extreme</option>
          </select>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <label className="flex items-center gap-2 text-xs"><input type="checkbox" className="accent-brand"/> With kids</label>
          <label className="flex items-center gap-2 text-xs"><input type="checkbox" className="accent-brand"/> With elders</label>
          <label className="flex items-center gap-2 text-xs"><input type="checkbox" className="accent-brand"/> Couple trip</label>
        </div>
        <div><label className="block mb-1 text-white/80">Hotel type</label><input className="w-full rounded-xl bg-white/5 border border-white/10 px-3 py-2 outline-none" placeholder="e.g., 3-star, 5-star, apartments"/></div>
        <div><label className="block mb-1 text-white/80">Special requests</label><textarea className="w-full rounded-xl bg-white/5 border border-white/10 px-3 py-2 outline-none" rows={3} placeholder="Shopping, museums, beaches, nightlife, etc."/></div>
        <button type="button" className="mt-4 rounded-full bg-brand hover:opacity-90 text-black text-sm px-6 py-2 transition">Continue to smart editor (placeholder)</button>
      </form>
    </section>
  </main>);
}
