import { NextResponse } from "next/server";
import { plans } from "@/lib/mockData";
export async function GET(_:Request,{params}:{params:{id:string}}){
  const plan=plans.find(p=>p.id===params.id);
  if(!plan) return NextResponse.json({error:"Not found"},{status:404});
  return NextResponse.json({plan});
}
