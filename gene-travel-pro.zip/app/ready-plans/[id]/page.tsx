import { plans } from "@/lib/mockData";
import Navbar from "@/components/Navbar";
import Image from "next/image";
type Props={params:{id:string}};
export default function ReadyPlanDetailPage({params}:Props){
  const plan=plans.find(p=>p.id===params.id);
  if(!plan){return(<main className="min-h-screen bg-black text-white flex items-center justify-center"><p>Plan not found.</p></main>);}
  return(<main className="min-h-screen bg-black text-white">
    <Navbar/>
    <section className="pt-24 pb-16 max-w-5xl mx-auto px-4">
      <div className="relative h-64 rounded-3xl overflow-hidden mb-8">
        <Image src={plan.image} alt={plan.title} fill className="object-cover"/>
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent"/>
        <div className="absolute bottom-4 left-4">
          <h1 className="text-3xl font-semibold">{plan.title}</h1>
          <p className="text-sm text-white/70">{plan.subtitle}</p>
        </div>
      </div>
      <p className="text-sm text-white/70 mb-6">Day-by-day program will appear here with hotels, car rentals, flights, and activities (affiliate buttons).</p>
    </section>
  </main>);
}
