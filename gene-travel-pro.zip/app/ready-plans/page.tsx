import { plans } from "@/lib/mockData";
import Link from "next/link";
import Navbar from "@/components/Navbar";
export default function ReadyPlansPage(){
  return(<main className="min-h-screen bg-black text-white">
    <Navbar/>
    <section className="pt-28 pb-16 max-w-6xl mx-auto px-4">
      <h1 className="text-3xl font-semibold mb-6">Ready Plans Library</h1>
      <p className="text-white/60 mb-8 max-w-2xl text-sm">Browse public itineraries. Later this will include filters.</p>
      <div className="grid gap-6 md:grid-cols-3">
        {plans.map(p=>(
          <Link key={p.id} href={`/ready-plans/${p.id}`} className="rounded-2xl bg-white/5 hover:bg-white/10 transition p-4">
            <h2 className="font-semibold mb-1">{p.title}</h2>
            <p className="text-xs text-white/70 mb-2">{p.subtitle}</p>
            <p className="text-[11px] text-white/60">{p.days} days • Budget {p.budgetBand}</p>
          </Link>
        ))}
      </div>
    </section>
  </main>);
}
