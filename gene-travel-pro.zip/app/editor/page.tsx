import Navbar from "@/components/Navbar";
export default function EditorPage(){
  return(<main className="min-h-screen bg-black text-white">
    <Navbar/>
    <section className="pt-28 pb-16 max-w-5xl mx-auto px-4 space-y-4">
      <h1 className="text-3xl font-semibold">Day Timeline Editor</h1>
      <p className="text-sm text-white/70">Placeholder for the rule-based editor (time, weather, budget, fatigue), Smart Recovery Mode, search & replace, and alerts.</p>
    </section>
  </main>);
}
