import Image from "next/image";
import Navbar from "@/components/Navbar";
import CinematicCards from "@/components/CinematicCards";
export default function HomePage(){
  const bg="/bg/home-hero.jpg";
  return(<main className="relative min-h-screen overflow-hidden text-white">
    <div className="absolute inset-0 -z-10">
      <Image src={bg} alt="background" fill priority className="object-cover opacity-85"/>
      <div className="absolute inset-0 bg-gradient-to-b from-black/30 to-black"/>
    </div>
    <Navbar/>
    <section className="pt-32 pb-16">
      <div className="text-center mb-10 px-4">
        <h1 className="text-4xl md:text-5xl font-semibold mb-4">Smart cinematic trips, built in seconds.</h1>
        <p className="text-white/70 max-w-2xl mx-auto text-sm md:text-base">Explore ready-made adventures or create your perfect plan with Gene&apos;s AI-powered travel engine.</p>
      </div>
      <CinematicCards/>
    </section>
  </main>);
}
