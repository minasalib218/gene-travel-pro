"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
const nav=[{href:"/",label:"Home"},{href:"/ready-plans",label:"Ready Plans"},{href:"/pricing",label:"Pricing"},{href:"/planner",label:"AI Planner"}];
export default function Navbar(){
  const pathname=usePathname();
  return(<header className="fixed top-0 left-0 right-0 z-30 pointer-events-none">
    <nav className="pointer-events-auto mx-auto mt-4 max-w-6xl flex items-center justify-between rounded-full bg-black/50 backdrop-blur-xl px-6 py-3 shadow-[0_10px_30px_rgba(0,0,0,0.6)]">
      <div className="flex items-center gap-2 select-none">
        <div className="h-8 w-8 rounded-full bg-gradient-to-br from-brand to-orange-600 flex items-center justify-center text-lg font-bold text-black">G</div>
        <div className="text-xs md:text-sm tracking-wide text-white/80"><span className="font-semibold">Gene</span> <span className="text-white/60">Travel Planner</span></div>
      </div>
      <div className="flex items-center gap-6 text-sm text-white/70">
        {nav.map(it=>{const active=pathname===it.href;return(
          <Link key={it.href} href={it.href} className="group relative inline-flex flex-col items-center hover:text-white transition-colors duration-200">
            <span className={active?"text-white":""}>{it.label}</span>
            <span className={`mt-1 h-[2px] rounded-full bg-brand transition-all duration-300 ${active?"w-6":"w-0 group-hover:w-6"}`} />
          </Link>
        );})}
      </div>
    </nav>
  </header>);
}
