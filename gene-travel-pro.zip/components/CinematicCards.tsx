"use client";
import Image from "next/image";
import { useRef, useState } from "react";
import { plans as homePlans } from "@/lib/mockData";
import Link from "next/link";
export default function CinematicCards(){
  const [active,setActive]=useState(0);
  const rowRef=useRef<HTMLDivElement>(null);
  const scrollBy=(offset:number)=>rowRef.current?.scrollBy({left:offset,behavior:"smooth"});
  return(<div className="relative w-full max-w-[1100px] mx-auto px-6">
    <button aria-label="previous" onClick={()=>scrollBy(-(320+32))} className="absolute left-0 top-1/2 -translate-y-1/2 z-20 rounded-full bg-white/5 backdrop-blur-md px-3 py-3 text-xl text-white hover:bg-white/10 hover:scale-105 transition">⟵</button>
    <button aria-label="next" onClick={()=>scrollBy(320+32)} className="absolute right-0 top-1/2 -translate-y-1/2 z-20 rounded-full bg-white/5 backdrop-blur-md px-3 py-3 text-xl text-white hover:bg-white/10 hover:scale-105 transition">⟶</button>
    <div ref={rowRef} className="flex gap-8 overflow-x-auto py-10 scrollbar-hide">
      {homePlans.map((p,i)=>(
        <Link key={p.id} href={`/ready-plans/${p.id}`} className="min-w-[300px] max-w-[300px] group" onClick={()=>setActive(i)}>
          <div className={`glass overflow-hidden ${active===i?"scale-105":"scale-95"} group-hover:scale-105 transition-transform`}>
            <div className="relative h-[360px]">
              <Image src={p.image} alt={p.title} fill className="object-cover"/>
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent"/>
              <div className="absolute bottom-0 p-5">
                <div className="text-sm text-white/70">{p.subtitle}</div>
                <div className="text-xl font-semibold">{p.title}</div>
                <div className="text-xs text-white/70 mt-1">{p.days} days · Budget {p.budgetBand}</div>
                <div className="flex flex-wrap gap-2 mt-3">
                  {p.tags.map(t=>(<span key={t} className="px-2 py-1 text-xs rounded-full bg-black/40">{t}</span>))}
                </div>
                <div className="mt-4 text-sm text-white/80">Quick view →</div>
              </div>
            </div>
          </div>
        </Link>
      ))}
    </div>
  </div>);
}
